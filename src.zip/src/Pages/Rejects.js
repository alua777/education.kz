import Card from '../Components/Card';
import Filter from '../Components/Filter';
import List from '../Components/List';

function Rejects() {
  return (
    <div>
      
    </div>
  );
}

export default Rejects;
