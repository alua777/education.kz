import Card from '../Components/Card';
import ChatWindow from '../Components/ChatWindow';
import Filter from '../Components/Filter';
import List from '../Components/List';

function Chat() {
  return (
    <div  style={{marginTop: '20px'}}>
      <ChatWindow></ChatWindow>
    </div>
  );
}

export default Chat;
